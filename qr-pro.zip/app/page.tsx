'use client';

import { useRef, useState } from "react";
import QRCode from "react-qr-code";
import * as htmlToImage from "html-to-image";

export default function Home() {
  const [text, setText] = useState("");
  const [value, setValue] = useState("");
  const qrRef = useRef(null);

  const downloadQR = async () => {
    if (!qrRef.current) return;
    const dataUrl = await htmlToImage.toPng(qrRef.current);
    const link = document.createElement("a");
    link.download = "qr.png";
    link.href = dataUrl;
    link.click();
  };

  return (
    <div style={{ padding: 20, textAlign: "center" }}>
      <h1>QR Code Generator PRO</h1>

      <input
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter text or URL"
        style={{ padding: 10, width: "80%" }}
      />

      <br /><br />

      <button onClick={() => setValue(text)}>Generate</button>

      {value && (
        <div ref={qrRef} style={{ marginTop: 20, background: "white", display: "inline-block", padding: 20 }}>
          <QRCode value={value} />
        </div>
      )}

      <br /><br />

      {value && <button onClick={downloadQR}>Download PNG</button>}
    </div>
  );
}
